#include"RRT_star.h"
#include "omp.h"

using namespace std;
using namespace Eigen;



//RRT* node
Node::Node() {
    parent= nullptr;
    cost=0;
}

Node::~Node(){
}

//RRTSTAR class Constructors
RRTSTAR::RRTSTAR(Point start_pos, Point end_pos, float radius, float end_thresh,World* w) {
    //set the default values and set the fist node as the staring point
    world = w;
    startPoint = start_pos;
    destination = end_pos;
    root = new Node;
    root->parent = nullptr;
    root->position = startPoint;
    root->cost = 0.0;
    lastnode = root;
    nodes.push_back(root);
    Available_Points.push_back(root->position);

    m_step_size = 0.75;
    m_max_iter = 7000;
    m_rrstar_radius = radius;
    m_destination_threshhold = end_thresh;
    m_num_itr = 0;
    m_cost_bestpath = 0;
    
    radius_fit_plane = 0.75;
    h_surf_car = 0.4;
}


Node RRTSTAR::getRandomNode() {
    std::random_device rand_rd;  //Will be used to obtain a seed for the random number engine
    std::mt19937 rand_gen(rand_rd()); //Standard mersenne_twister_engine seeded with rd()
    std::uniform_real_distribution<> rand_unif(0, 1.0);  // initialize a uniform distribution between 0 and 1
    float random[3];
	for (int i = 0; i < 3; i++)
	{
		random[i] = rand_unif(rand_gen);
	}

    Vector3d gl_lb = this->world->getglobalmaplb();
    Vector3d gl_ub = this->world->getglobalmapub();

    Point rand_point((gl_ub(0)-gl_lb(0))*random[0]+gl_lb(0),(gl_ub(1)-gl_lb(1))*random[1]+gl_lb(1),(gl_ub(2)-gl_lb(2))*random[2]+gl_lb(2));//Generate a random point

    if (rand_point.m_x >= gl_lb(0) && rand_point.m_x <= gl_ub(0) && rand_point.m_y >= gl_lb(1) && rand_point.m_y <= gl_ub(1) && rand_point.m_z >= gl_lb(2) && rand_point.m_z <= gl_ub(2)) 
    { //check of the generated point is inside the world!
        Node rand_randomnode;    
        rand_randomnode.position = rand_point;
        return rand_randomnode;
    }
    else{return {};}

}

Point RRTSTAR::steer(const Node n_rand, const Node* n_nearest) 
{ // Steer from new node towards the nearest neighbor and interpolate if the new node is too far away from its neighbor
    Point n_rand_projection = project2plane(n_rand.position);
    Point n_nearest_projection = project2plane(n_nearest->position);
    Point n_new_projection;//点在z = 0平面的投影
    Point n_new_surface;
    if (this->distance(n_rand_projection, n_nearest_projection) >this->m_step_size) 
    { //check if the distance between two nodes is larger than the maximum travel step size
        Point steer_p = n_rand_projection - n_nearest_projection;
        double steer_norm = this->distance(n_rand_projection, n_nearest_projection);
        steer_p = steer_p / steer_norm; //normalize the vector
        n_new_projection = n_nearest_projection +  steer_p * this->m_step_size;
        n_new_surface = project2surface(n_new_projection);//若无法投影则z默认为999
        return (n_new_surface); //travel in the direction of line between the new node and the near node
    }
    else {
        n_new_surface = project2surface(n_rand_projection);//若无法投影则z默认为999
        return  (n_new_surface);

    }
}


Node* RRTSTAR::findNearest(const Point point) {
    float fn_minDist = FLT_MAX;//set the minimum distance to the maximum number possible
    Node* fn_closest = NULL;

    #pragma omp parallel for    
    for (size_t i = 0; i < this->nodes.size(); i++) { //iterate through all nodes of the tree to find the closest to the new node
        // int omp_id = omp_get_thread_num();
        // if(omp_id == 0 && this->getCurrentIterations()%4000==0 ){
        //     printf("iter: %d, thread %d, Total %d of threads\n",this->getCurrentIterations(), omp_id, omp_get_num_threads());
        // }
        float fn_dist = this->distance(point, this->nodes[i]->position);
        if (fn_dist < fn_minDist) {
            fn_minDist = fn_dist;
            fn_closest = this->nodes[i];
        }
    }
    // TODO: should modify here since dependencies: 有4個threads的話，要比較4個中最近的neighbor!
    return fn_closest;
}

void RRTSTAR::findNearNeighbors(const Point point, const float radius, std::vector<Node*>& neighbor_nodes) { // Find neighbor nodes of the given node within the defined radius
    for (size_t i = 0; i < this->nodes.size(); i++) { //iterate through all nodes to see which ones fall inside the circle with the given radius.
        if (this->distance(point, this->nodes[i]->position) < radius) {
            neighbor_nodes.push_back(this->nodes[i]);
        }
    }
}

Node* RRTSTAR::findParent(std::vector<Node*> v_n_near,Node* n_nearest, Node* n_new) {
    Node* fp_n_parent = n_nearest; //create new note to find the parent
    float fp_cmin = this->getCost(n_nearest) + this->pathCost(n_nearest, n_new); // Update cost of reaching "N_new" from "N_Nearest"
    for (size_t j = 0; j < v_n_near.size(); j++) { //In all members of "N_near", check if "N_new" can be reached from a different parent node with cost lower than Cmin, and without colliding with the obstacle.
        Node* fp_n_near = v_n_near[j];
        if (!this->world->checkObstacle(fp_n_near->position, n_new->position) &&
            (this->getCost(fp_n_near) + this->pathCost(fp_n_near, n_new)) < fp_cmin) {
            fp_n_parent = fp_n_near; // a near node with minimun cost of path
            fp_cmin = this->getCost(fp_n_near) + this->pathCost(fp_n_near, n_new); //update the cost of path
        }
    }
    return fp_n_parent;
}

float RRTSTAR::getCost(const Node* N) { //get the cost current node (traveling from the given node to the root)
    return N->cost;
}


float RRTSTAR::pathCost(const Node* Np, const Node* Nq) { //Compute the distance between the position of two nodes
    return this->distance(Nq->position, Np->position);
}

void RRTSTAR::insertNode(Node* n_parent, Node* n_new) { //Append the new node to the tree.
    n_new->parent = n_parent; //update the parent of new node
    n_new->cost = n_parent->cost + this->pathCost(n_parent, n_new);//update the cost of new node
    n_parent->children.push_back(n_new); //update the children of the nearest node to the new node
    this->nodes.push_back(n_new);//add the new node to the tree
    this->Available_Points.push_back(n_new->position); //Add one more availble point! 

    this->lastnode = n_new;//inform the tree which node is just added
}

void RRTSTAR::reWire(Node* n_new, std::vector<Node*>& neighbor_nodes) { // Rewire the tree to decrease the cost of the path. 
    for (size_t j = 0; j < neighbor_nodes.size(); j++) {  // Search through nodes in "N_near" and see if changing their parent to "N_new" lowers the cost of the path. Also check the obstacles
        Node* rw_n_near = neighbor_nodes[j];
        if (!this->world->checkObstacle(n_new->position, rw_n_near->position) &&
            (this->getCost(n_new) + this->pathCost(n_new, rw_n_near)) < this->getCost(rw_n_near)) {
            Node* rw_n_parent = rw_n_near->parent;
            float rw_costdifference = this->getCost(rw_n_near) - (this->getCost(n_new) + this->pathCost(n_new, rw_n_near)); //calculate the cost  by which the cost of all children of the near node must decrease
            // Remove branch between N_Parent and N_Near
            rw_n_parent->children.erase(std::remove(rw_n_parent->children.begin(), rw_n_parent->children.end(), rw_n_near), rw_n_parent->children.end());
            // Add branch between N_New and N_Near
            rw_n_near->cost = this->getCost(n_new) + this->pathCost(n_new, rw_n_near);
            rw_n_near->parent = n_new;
            n_new->children.push_back(rw_n_near);
            // this->Available_Points.push_back(n_new->position);
            this->updateChildrenCost(rw_n_near, rw_costdifference);// Update the cost of all children of the near node 
        }
    }
}

// Here can I parallelize TOO.fn_closest
void RRTSTAR::updateChildrenCost(Node* n, const float costdifference) {//Update the cost of all children of a node after rewiring 
    for (size_t i = 0; i < n->children.size(); i++)
    {
        n->children[i]->cost = n->children[i]->cost - costdifference;
        this->updateChildrenCost(n->children[i], costdifference); //recursive function. call it self to go through all children of the given node.
    }
}

std::vector<Node*> RRTSTAR::generatePlan(Node* n) {// generate shortest path to destination.
    while (n != NULL) { // It goes from the given node to the root
        this->path.push_back(n);
        n = n->parent;
    }
    this->bestpath.clear();
    this->bestpath = this->path;    //store the current plan as the best plan so far

    this->path.clear(); //clear the path as we have stored it in the Bestpath variable.
    this->m_cost_bestpath = this->bestpath[0]->cost; //store the cost of the generated path
    return this->planFromBestPath();
}

std::vector<Node*> RRTSTAR::planFromBestPath() { // Generate plan (vector of points) from the best plan so far.
    // std::vector<Node*> pfb_generated_plan;
    // // Accelerate I/O here. 
    // for (size_t i = 0; i < this->bestpath.size(); i++) { // It goes from a node near destination to the root
    //     pfb_generated_plan.push_back(this->bestpath[i]);
    // }
    return this->bestpath;
}

//RRTSTAR methods
std::vector<Node*> RRTSTAR::planner() {
    // while iter < MAX_Iterations
    while (this->m_num_itr<this->m_max_iter)
    {
        this->m_num_itr++;
        Node plan_n_rand = this->getRandomNode(); //Pick a random node
        //cout<<plan_n_rand.position.m_x<<"  "<<plan_n_rand.position.m_y<<"  "<<plan_n_rand.position.m_z<<endl;
        if (plan_n_rand.position.m_x!=0 && plan_n_rand.position.m_y!=0 && plan_n_rand.position.m_z!=0 ) {
            
            Node* plan_n_nearest = this->findNearest(plan_n_rand.position);  //Find the closest node to the new random node.
            Point plan_p_new_surface = this->steer(plan_n_rand, plan_n_nearest); //Steer from "N_Nearest" towards "N_rand": interpolate if node is too far away.
            Node* plan_n_new = fitplane(plan_p_new_surface); //create new node to store the position of the steered node.
            if ((!this->world->checkObstacle(plan_n_new->position, plan_n_nearest->position))&&this->world->isInsideBorder(plan_n_new->position)&&(plan_n_new->plane.flatness<0.04)) //筛除两种节点：1，新点与最近点连线之间有障碍 2，超出边界，一般是由2D点找不到曲面投影引起的
            { // Check if an obstacle is between new node and nearest nod.
                     std::vector<Node*> plan_v_n_near; //create a vector for neighbor nodes
                     this->findNearNeighbors(plan_n_new->position, this->m_rrstar_radius, plan_v_n_near); // Find nearest neighbors with a given radius from new node.
                     Node* plan_n_parent=this->findParent(plan_v_n_near,plan_n_nearest,plan_n_new); //Find the parent of the given node (the node that is near and has the lowest path cost)
                     this->insertNode(plan_n_parent, plan_n_new);//Add N_new to node list.
                     this->reWire(plan_n_new, plan_v_n_near); //rewire the tree

                     if (this->reached() && this->bestpath.empty()) { //find the first viable path
                         return this->generatePlan(this->lastnode);
                     }

                     if (!this->bestpath.empty()) { //find more optimal paths
                         if (this->reached()) {
                             // If we get a better path (lower cost)!
                             if (this->lastnode->cost < this->m_cost_bestpath) {
                                 return this->generatePlan(this->lastnode);
                             }
                         }
                         else {
                             // Havent reach the goal, ??? Why here.
                             Node* Plan_NearNodeEnd = this->findNearest(this->destination);
                             if (Plan_NearNodeEnd->cost < this->m_cost_bestpath) {
                                 return this->generatePlan(Plan_NearNodeEnd);
                             }
                         }
                     }
                    
            }            
        }
        
    }
    
    if (this->bestpath.empty()) {
        // if not reached yet, no solution has found
        std::cout << "Exceeded max iterations!" << std::endl;
        std::cout << "Error: No solution found" << std::endl;
        // this->savePlanToFile({}, "Mfiles//Path_after_MAX_ITER.txt", "Error: No solution found");
        // this->savePlanToFile({}, "Mfiles//first_viable_path.txt", "Error: No solution found");
        return {};
    }
    else {
        return RRTSTAR::planFromBestPath(); //after reaching the maximum iteration number retun the path that has the lowest cost.
    }
        
}

float RRTSTAR::distance(const Point p, const Point q) { //Find the distance between two points.
    Point dist_v = p - q;
    return sqrt(powf(dist_v.m_x, 2) + powf(dist_v.m_y, 2) + powf(dist_v.m_z, 2));
}

Point RRTSTAR::project2plane (const Point p){
    Point p_plane;
    p_plane.m_x = p.m_x;
    p_plane.m_y = p.m_y;
    p_plane.m_z = 0;
    return p_plane;
}

Point RRTSTAR::project2surface (const Point p){
    Point p_surface;
    double check_step = world->getglobalmapresolution();
    double zub = (world->getglobalmapub())(2);
    double zlb = (world->getglobalmaplb())(2);

    p_surface.m_x = p.m_x;
    p_surface.m_y = p.m_y;  
    p_surface.m_z = 999;
    //默认最底下那个是地面点
    for(double z = zlb;z < zub;z = z+check_step){
        if(world->isObsFree(p.m_x,p.m_y,z) == false){
            p_surface.m_z = z;
            return p_surface;
        }
    }//若没有找到则默认z=999;
    return p_surface;
}

//拟合曲面并且返回生成的节点
Node* RRTSTAR::fitplane (const Point p){
    Node* n = new Node;

    if(p.m_z < world->getglobalmapub()(2)){//确保2D映射到3D曲面
 
        Plane plane(p.m_x,p.m_y,p.m_z,world,radius_fit_plane);
    
        if(!plane.plane_pts.empty()){
            std::vector  <Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d> > plane_pts;
            for(int i = 0;i<plane.plane_pts.size();i++){
                Vector3d tmp(plane.plane_pts[i].m_x,plane.plane_pts[i].m_y,plane.plane_pts[i].m_z);
                plane_pts.push_back(tmp);
            }
            Eigen::Vector3d center = Eigen::Vector3d::Zero();
            for (const auto & pt : plane_pts) center += pt;
            center /= plane_pts.size();
            Eigen::MatrixXd A(plane_pts.size(), 3);
            for (int i = 0; i < plane_pts.size(); i++) {
                A(i, 0) = plane_pts[i][0] - center[0];
                A(i, 1) = plane_pts[i][1] - center[1];
                A(i, 2) = plane_pts[i][2] - center[2];
            }
            //cout<<plane.plane_pts.size()<<endl;
            Eigen::JacobiSVD<Eigen::MatrixXd> svd(A, Eigen::ComputeThinV);
            const float a = svd.matrixV()(0, 2);
            const float b = svd.matrixV()(1, 2);
            const float c = svd.matrixV()(2, 2);
            const float d = -(a * center[0] + b * center[1] + c * center[2]);
            plane.setplane(a,b,c,d);
            //在拟合的平面方向上设置高度
            n->position.m_x = p.m_x + h_surf_car*a;
            n->position.m_y = p.m_y + h_surf_car*b;
            n->position.m_z = p.m_z + h_surf_car*c;
            n->plane = plane;
            //计算平面度
            
            float flatness = 0;
            for (int i = 0; i < plane_pts.size(); i++) {
                flatness = flatness + sqrt(powf(a*A(i, 0) + b*A(i, 1) + c*A(i, 2), 2));;
            }
            flatness = flatness / plane_pts.size();
            n->plane.flatness = flatness;
            
            
        }
    }
    return n;
}


bool RRTSTAR::reached() { //check if the last node in the tree is close to the end position.
    if (this->distance(this->lastnode->position, this->destination) < m_destination_threshhold) {
        return true;
    }
    return false;
}
int RRTSTAR::getCurrentIterations() {
    return this->m_num_itr;
}

int RRTSTAR::getMaxIterations() { //get the maximum number of iteration of the RRT* algorithm
    return this->m_max_iter;
}